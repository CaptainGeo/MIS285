value = int(input('Please input a number which corresponds to a day of the week: '))

if value == 1:
    print('MONDAY')
elif value == 2:
    print('TUESDAY')
elif value == 3:
    print('WEDNESDAY')
elif value == 4:
    print('THURSDAY')
elif value == 5:
    print('FRIDAY')
elif value == 6:
    print('SATURDAY')
elif value == 7:
    print('SUNDAY')
else:
    print('ERROR: Invalid input. Please enter a number from 1 to 7.')
