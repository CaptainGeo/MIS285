cpm = 4.2
for min in range(10,31,5):
    cals = min*cpm
    print("Calories burned after", min, "minutes =",cals)
