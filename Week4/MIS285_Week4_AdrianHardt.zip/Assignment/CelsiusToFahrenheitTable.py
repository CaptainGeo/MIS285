celsius = 0

while celsius <= 20:
    fahrenheit = (celsius*9/5)+32
    print('C =', celsius, "F =", fahrenheit, sep = '\t')
    celsius += 1
