celsius = float(input('Please input temperature in degrees Celsius: '))

fahrenheit = (celsius*9/5)+32

print("That temperature in Fahrenheit is: ", fahrenheit, 'degrees.')
