sqFeet = int(input("Please enter number of square feet:"))
print("Acres =",format(sqFeet/43560,'.2f'))
