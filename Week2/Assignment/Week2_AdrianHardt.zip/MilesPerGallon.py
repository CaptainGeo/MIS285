miles = float(input("Please enter # of miles driven: "))
gallons = float(input("Please enter # of gallons of fuel: "))

print("MPG for this trip is:",format(miles/gallons,'.2f'))
