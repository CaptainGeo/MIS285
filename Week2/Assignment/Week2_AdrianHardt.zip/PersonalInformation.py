print("Adrian Hardt")
print("909 NE Alameda St. Portland, OR 97070")
print("503-244-0234")
print("IT and Cybersecurity")
