from turtle import *
while True:
    forward(200)
    left(250)
    back(150)
    right(125)
